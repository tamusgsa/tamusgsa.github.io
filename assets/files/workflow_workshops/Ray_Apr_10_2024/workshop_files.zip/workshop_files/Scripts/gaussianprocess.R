library(MASS)

# Distance matrix between X and Y (this requires some boring algebra)
distmat = function(X, Y) {
  m = nrow(X)
  n = nrow(Y)
  XY = X %*% t(Y)
  XX = matrix(rep(apply(X * X, 1, sum), n), m, n, byrow = F)
  YY = matrix(rep(apply(Y * Y, 1, sum), m), m, n, byrow = T)
  sqrt(pmax(XX + YY - 2 * XY, 0))
}
# Pairwise distances between each element of X
pdist = function(X) {
  distmat(X, X)
}

rbf_kernel = function(pairwise_dist_mat, length_scale) {
  return(exp(-0.5 * (1/length_scale^2) * pairwise_dist_mat))
}

simulate_GP = function(n_obs, n_test, spatial_dim, length_scale, noise_var = 0.1) {
  coords = runif(n_obs*spatial_dim) |> matrix(nrow = n_obs, ncol = spatial_dim)
  coords_test = runif(n_test*spatial_dim) |> matrix(nrow = n_test, ncol = spatial_dim)
  kernel_true = rbind(coords, coords_test) |>
    dist() |> as.matrix() |> rbf_kernel(length_scale)
  y_sim_true = MASS::mvrnorm(1, mu = rep(0, n_obs + n_test),
                             Sigma = kernel_true) +
                rnorm(n_obs + n_test, sd = sqrt(noise_var))
  return(list(X = coords,
              X_test = coords_test,
              Y = y_sim_true[1:n_obs],
              Y_test = y_sim_true[(n_obs + 1):n_test]))
}

predict_GP = function(X, Y, X_new, length_scale, noise_var = 0.1) {
  K_xstar_xstar = pdist(X_new) |> rbf_kernel(length_scale)
  K_xstar_x = distmat(X_new, X) |> rbf_kernel(length_scale)
  K_x_x = pdist(X) |> rbf_kernel(length_scale)
  K_x_x_inv = solve(K_x_x)
  posterior_mean = K_xstar_x %*% K_x_x_inv %*% Y
  posterior_var = K_xstar_xstar - (K_xstar_x %*% K_x_x_inv %*% t(K_xstar_x))
  return(list(posterior_mean = posterior_mean,
              posterior_var = posterior_var))
}

#example_sim = simulate_GP(10, 50, 2, 0.1)
#example_pred = predict_GP(example_sim$X, example_sim$Y, example_sim$X_test, 0.1)

## Hand rolled MV Normal generation
chol_mvrnorm = function(n = 1, mu, Sigma) {
  p = length(mu)
  # p by p
  D = chol(Sigma)
  # Once we have D, just an affine transform
  rep(mu, n) + matrix(rnorm(n * p), ncol = p) %*% D
}

simulate_GP_chol = function(n_obs, n_test, spatial_dim, length_scale, noise_var = 0.1) {
  coords = runif(n_obs*spatial_dim) |> matrix(nrow = n_obs, ncol = spatial_dim)
  coords_test = runif(n_test*spatial_dim) |> matrix(nrow = n_test, ncol = spatial_dim)
  kernel_true = rbind(coords, coords_test) |>
    dist() |> as.matrix() |> rbf_kernel(length_scale)
  y_sim_true = chol_mvrnorm(1, mu = rep(0, n_obs + n_test),
                            Sigma = kernel_true) +
    rnorm(n_obs + n_test, sd = sqrt(noise_var))
  return(list(X = coords,
              X_test = coords_test,
              Y = y_sim_true[1:n_obs],
              Y_test = y_sim_true[(n_obs + 1):n_test]))
}


## Hand rolled again, but this time using better Data Structures and Algorithms
## such as Matrix instead of matrix, crossprod, etc.

library(Matrix)

rbf_kernel_DS = function(pairwise_dist_mat, length_scale) {
  return(exp(-0.5 * (1/length_scale^2) * pairwise_dist_mat))
}

distmat_DS = function(X, Y) {
  m = nrow(X)
  n = nrow(Y)
  XY = tcrossprod(X, Y)
  XX = Matrix(rep(rowSums(X^2), n), m, n, byrow = F)
  YY = Matrix(rep(rowSums(Y^2), m), m, n, byrow = T)
  sqrt(pmax(XX + YY - 2 * XY, 0))
}
# Pairwise distances between each element of X
pdist_DS = function(X) {
  distmat_DS(X, X)
}

chol_mvrnorm_DS = function(n = 1, mu, Sigma) {
  p = length(mu)
  # p by p
  D = chol(Sigma)
  # Once we have D, just an affine transform
  rep(mu, n) + crossprod(Matrix(rnorm(n * p), ncol = n), D)
}

simulate_GP_DS = function(n_obs, n_test, spatial_dim, length_scale, noise_var = 0.1) {
  coords = runif(n_obs*spatial_dim) |> Matrix(nrow = n_obs, ncol = spatial_dim)
  coords_test = runif(n_test*spatial_dim) |> Matrix(nrow = n_test, ncol = spatial_dim)
  kernel_true = rbind(coords, coords_test) |>
    dist() |> as.matrix() |> Matrix() |> rbf_kernel_DS(length_scale)
  y_sim_true = chol_mvrnorm_DS(1, mu = rep(0, n_obs + n_test),
                               Sigma = kernel_true) +
    rnorm(n_obs + n_test, sd = sqrt(noise_var))
  return(list(X = coords,
              X_test = coords_test,
              Y = y_sim_true[1:n_obs],
              Y_test = y_sim_true[(n_obs + 1):n_test]))
}

predict_GP_DS = function(X, Y, X_new, length_scale, noise_var = 0.1) {
  K_xstar_xstar = pdist(X_new) |> rbf_kernel_DS(length_scale)
  K_xstar_x = distmat(X_new, X) |> rbf_kernel_DS(length_scale)
  K_x_x = pdist(X) |> rbf_kernel_DS(length_scale)
  K_x_x_inv = solve(K_x_x)
  posterior_mean = K_xstar_x %*% K_x_x_inv %*% Y
  posterior_var = K_xstar_xstar - (K_xstar_x %*% tcrossprod(K_x_x_inv, K_xstar_x))
  return(list(posterior_mean = posterior_mean,
              posterior_var = posterior_var))
}


