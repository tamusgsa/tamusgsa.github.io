library(tidyverse)
library(microbenchmark)
source("Scripts/gaussianprocess.R", local = TRUE)
set.seed(12345)

N_grid = 2^(4:10)
N_star_grid = 2^(4:10)
length_scale = 0.1
noise_var = 0.1
dim = 2

N_benchmark = 2^9
N_star_benchmark = 2^9

print(sessionInfo())

## Naive Implementation
naive_impl = function(N, N_star) {
  sim = simulate_GP(N, N_star, dim, length_scale, noise_var)
  pred = predict_GP(sim$X, sim$Y, sim$X_test, length_scale, noise_var)
  return(pred)
}

# naive_microbench_grid = pmap(list(N_grid = N_grid,
#                              N_star_grid = N_star_grid),
#                         ~ microbenchmark(naive_impl(..1, ..2),
#                                          times = 10),
#                         .progress = TRUE)

naive_prof = profvis::profvis({naive_impl(N_benchmark, N_star_benchmark)})
saveRDS(naive_prof, file = "Data/naive_prof.RDS")

## After first benchmark identified mvrnorm as the issue, roll our own function to sample
bespoke_mvrnorm_impl = function(N, N_star) {
  sim = simulate_GP_chol(N, N_star, dim, length_scale, noise_var)
  pred = predict_GP(sim$X, sim$Y, sim$X_test, length_scale, noise_var)
  return(pred)
}

bespoke_mvrnorm_prof = profvis::profvis({bespoke_mvrnorm_impl(N_benchmark, N_star_benchmark)})
saveRDS(bespoke_mvrnorm_prof, file = "Data/bespoke_mvrnorm_prof.RDS")

## What if we use better data structures? Matrix in particular

better_ds_impl = function(N, N_star) {
  sim = simulate_GP_DS(N, N_star, dim, length_scale, noise_var)
  pred = predict_GP_DS(sim$X, sim$Y, sim$X_test, length_scale, noise_var)
  return(pred)
}

better_ds_prof = profvis::profvis({better_ds_impl(N_benchmark, N_star_benchmark)})
saveRDS(better_ds_prof, file = "Data/better_ds_prof.RDS")

## What if we byte compile?

byte_comp_impl = compiler::cmpfun(better_ds_impl, list(optimize = 3))

byte_comp_prof = profvis::profvis({byte_comp_impl(N_benchmark, N_star_benchmark)})
saveRDS(byte_comp_prof, file = "Data/byte_comp_prof.RDS")

full_microbench = microbenchmark(
  Naive = naive_impl(N_benchmark, N_star_benchmark),
  BespokeMVN = bespoke_mvrnorm_impl(N_benchmark, N_star_benchmark),
  DataStructures = better_ds_impl(N_benchmark, N_star_benchmark),
  ByteCompile = byte_comp_impl(N_benchmark, N_star_benchmark),
  times = 30,
  control = list(order = "inorder", warmup = 5)
)
session = sessionInfo()
simname = paste0("Data/micro_", session$BLAS, session$LAPACK, session$LA_version, ".RDS")
saveRDS(full_microbench, file = simname)

#### Bespoke C++ ####

source("Scripts/wrap_gpRcpp.R")


